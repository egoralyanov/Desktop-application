#include "onb6.h"
#include "ui_onb6.h"
#include "authenticationmanager.h"
#include "databasehelper.h"
#include "menuwindow.h"
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QTimer>
#include <QDateTime>
#include <QHBoxLayout>
#include <QSqlRecord>
#include <QFile>
#include <QTextStream>
onb6::onb6(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::onb6)
{
    ui->setupUi(this);


    // Подключение сигналов к слотам
    connect(ui->btn1, SIGNAL(clicked(bool)), this, SLOT(add()));
    connect(ui->btn2, SIGNAL(clicked(bool)), this, SLOT(edit()));
    connect(ui->btn3, SIGNAL(clicked(bool)), this, SLOT(remove()));
    connect(ui->btn4, SIGNAL(clicked(bool)), this, SLOT(clean()));
    connect(ui->btnSearch, &QPushButton::clicked, this, &onb6::search);
    connect(ui->btnReport, &QPushButton::clicked, this, &onb6::generateReportRequest);
    // Вызываем метод selectAll() через таймер с нулевой задержкой, чтобы он выполнился после инициализации интерфейса
    QTimer::singleShot(0, this, &onb6::selectAll);

    // Задаем количество столбцов в компоненте таблицы
    ui->tw->setColumnCount(8);

    // Задаем заголовки столбцов таблицы
    ui->tw->setHorizontalHeaderItem(0, new QTableWidgetItem("ID"));
    ui->tw->setHorizontalHeaderItem(1, new QTableWidgetItem("Дата"));
    ui->tw->setHorizontalHeaderItem(2, new QTableWidgetItem("Цена"));
    ui->tw->setHorizontalHeaderItem(3, new QTableWidgetItem("Клиент"));
    ui->tw->setHorizontalHeaderItem(4, new QTableWidgetItem("Работник"));
    ui->tw->setHorizontalHeaderItem(5, new QTableWidgetItem("Продукт"));
    ui->tw->setHorizontalHeaderItem(6, new QTableWidgetItem("Склад"));
    ui->tw->setHorizontalHeaderItem(7, new QTableWidgetItem("Поставщик"));



    // Устанавливаем растягивание последнего столбца при изменении размера формы
    ui->tw->horizontalHeader()->setStretchLastSection(true);

    // Включаем возможность прокрутки содержимого таблицы
    ui->tw->setAutoScroll(true);

    // Устанавливаем режим выделения ячеек: только одна строка
    ui->tw->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tw->setSelectionBehavior(QAbstractItemView::SelectRows);

    // Разрешаем пользователю сортировать данные по столбцам
    ui->tw->setSortingEnabled(true);
    ui->tw->sortByColumn(0, Qt::AscendingOrder);

    // Запрещаем редактирование ячеек таблицы
    ui->tw->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // Заполнение выпадающих списков
    populate1ComboBox();
    populate2ComboBox();
    populate3ComboBox();
    populate4ComboBox();
    populate5ComboBox();


}

onb6::~onb6()
{
    delete ui;
}



void onb6::on_btnExit_clicked()
{
    // Создаем объект AuthenticationManager
    AuthenticationManager authenticationManager;

    // Получаем логин текущего пользователя через созданный объект
    QString currentUser = authenticationManager.getCurrentUserLogin();

    // Получаем список разрешенных кнопок для текущего пользователя
    QStringList allowedButtons = authenticationManager.getAllowedButtons(currentUser);


    close();

    // Создаем и отображаем новое окно главного меню с передачей списка разрешенных кнопок
    menuwindow *menuWindow = new menuwindow(allowedButtons);
    menuWindow->show();
}



void onb6::populate1ComboBox()
{
    ui->cmb1->clear();
    QSqlQuery query("SELECT client_id, client_name FROM client ORDER BY client_name");
    while (query.next()) {
        QString pu1 = query.value("client_id").toString();
        QString pu2 = query.value("client_name").toString();
        ui->cmb1->addItem(pu2, pu1);
    }
}

void onb6::populate2ComboBox()
{
    ui->cmb2->clear();
    QSqlQuery query("SELECT employee_id, employee_name FROM employee ORDER BY employee_name");
    while (query.next()) {
        QString pu1 = query.value("employee_id").toString();
        QString pu2 = query.value("employee_name").toString();
        ui->cmb2->addItem(pu2, pu1);
    }
}


void onb6::populate3ComboBox()
{
    ui->cmb3->clear();
    QSqlQuery query("SELECT product_id, product_name FROM product ORDER BY product_name");
    while (query.next()) {
        QString pu1 = query.value("product_id").toString();
        QString pu2 = query.value("product_name").toString();
        ui->cmb3->addItem(pu2, pu1);
    }
}

void onb6::populate4ComboBox()
{
    ui->cmb4->clear();
    QSqlQuery query("SELECT warehouse_id, warehouse_name FROM warehouse ORDER BY warehouse_name");
    while (query.next()) {
        QString pu1 = query.value("warehouse_id").toString();
        QString pu2 = query.value("warehouse_name").toString();
        ui->cmb4->addItem(pu2, pu1);
    }
}

void onb6::populate5ComboBox()
{
    ui->cmb5->clear();
    QSqlQuery query("SELECT supplier_id, supplier_legal_entity FROM supplier ORDER BY supplier_legal_entity");
    while (query.next()) {
        QString pu1 = query.value("supplier_id").toString();
        QString pu2 = query.value("supplier_legal_entity").toString();
        ui->cmb5->addItem(pu2, pu1);
    }
}


void onb6::selectAll()
{
    // Проверяем, открыто ли соединение с базой данных
    if (!DatabaseHelper::isDatabaseConnected())
    {
        QMessageBox::critical(this, "Ошибка", "База данных не подключена.");
        return;
    }

    QSqlQuery query(DatabaseHelper::getDatabaseConnection());

    QString sqlstr = "SELECT deal_id, "
                     "deal_date, "
                     "deal_price, "
                     "(SELECT client_name FROM client WHERE client_id = deal.client_id) AS c, "
                     "(SELECT employee_name FROM employee WHERE employee_id = deal.employee_id) AS e, "
                     "(SELECT product_name FROM product WHERE product_id = deal.product_id) AS p, "
                     "(SELECT warehouse_name FROM warehouse WHERE warehouse_id = deal.warehouse_id) AS w, "

                     "(SELECT supplier_legal_entity FROM supplier WHERE supplier_id = deal.supplier_id) AS ss "
                     "FROM deal "
                     "ORDER BY deal_id, c, e, p, w, ss";

    if (!query.exec(sqlstr))
    {
        QMessageBox::critical(this, "Ошибка", query.lastError().text());
        return;
    }


    ui->tw->clearContents();


    ui->tw->setRowCount(0);

    int rowCount = 0;


    while (query.next())
    {

        ui->tw->insertRow(rowCount);


        for (int col = 0; col < ui->tw->columnCount(); ++col)
        {
            QTableWidgetItem *item = new QTableWidgetItem();
            item->setData(Qt::DisplayRole, query.value(col));
            ui->tw->setItem(rowCount, col, item);
        }

        rowCount++;
    }


    ui->tw->resizeColumnsToContents();
}

void onb6::add()
{
    QString pu2 = ui->le2->text(); // deal_date
    QString pu3 = ui->le3->text(); // deal_price
    QString cmb = ui->cmb1->currentData().toString(); // client_id
    QString cmbb = ui->cmb2->currentData().toString(); // employee_id
    QString cmbbb = ui->cmb3->currentData().toString(); // product_id
    QString cmbbbb = ui->cmb4->currentData().toString(); // warehouse_id
    QString cmbbbbb = ui->cmb5->currentData().toString(); // supplier_id

    // Проверка корректности формата даты
    QDate date = QDate::fromString(pu2, "yyyy-MM-dd");
    if (!date.isValid()) {
        QMessageBox::critical(this, "Ошибка", "Некорректный формат даты. Ожидается формат yyyy-MM-dd.");
        return;
    }

    // Проверка, что цена не отрицательная
    bool ok;
    double price = pu3.toDouble(&ok);
    if (!ok || price < 0) {
        QMessageBox::critical(this, "Ошибка", "Цена не может быть отрицательной.");
        return;
    }

    // Подготавливаем SQL запрос для вставки данных
    QSqlQuery query;
    query.prepare("INSERT INTO deal (deal_date, deal_price, client_id, employee_id, product_id, warehouse_id, supplier_id) "
                  "VALUES (:1, :2, :3, :4, :5, :6, :7)");
    query.bindValue(":1", pu2);
    query.bindValue(":2", pu3);
    query.bindValue(":3", cmb);
    query.bindValue(":4", cmbb);
    query.bindValue(":5", cmbbb);
    query.bindValue(":6", cmbbbb);
    query.bindValue(":7", cmbbbbb);

    // Выполняем SQL запрос для вставки данных
    if (!query.exec()) {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
        ui->teResult->append("Error: " + query.lastError().text());
        return;
    }

    qDebug() << "Данные успешно добавлены в базу данных.";
    ui->teResult->append("Успех: данные успешно добавлены.");
    selectAll(); // Обновить таблицу, чтобы отобразить новые данные
}



void onb6::remove()
{
    // Проверяем, открыто ли соединение с базой данных
    if (!DatabaseHelper::isDatabaseConnected())
    {
        QMessageBox::critical(this, "Ошибка", "База данных не подключена.");
        return;
    }

    // Получаем текущую выбранную строку
    int curRow = ui->tw->currentRow();

    // Проверяем, что выбранная строка действительно существует
    if (curRow < 0)
    {
        QMessageBox::critical(this, "Ошибка", "Строка не выбрана!");
        return;
    }

    // Просим пользователя подтвердить удаление строки
    if (QMessageBox::question(this, "Удалить", "Удалить строку?", QMessageBox::Cancel, QMessageBox::Ok) == QMessageBox::Cancel)
        return;

    // Создаем объект запроса
    QSqlQuery query(DatabaseHelper::getDatabaseConnection());

    QString pu1 = ui->tw->item(curRow, 0)->text();

    // Подготавливаем строку запроса для удаления данных из таблицы
    QString sqlstr = "DELETE FROM deal WHERE deal_id = :1";

    // Подготавливаем запрос к выполнению
    query.prepare(sqlstr);
    query.bindValue(":1", pu1);

    // Выполняем запрос
    if (!query.exec())
    {
        // Проверяем текст ошибки на наличие фразы "foreign key"
        if (query.lastError().text().contains("foreign key", Qt::CaseInsensitive))
        {
            QMessageBox::critical(this, "Ошибка", "Невозможно удалить, так как есть связанные записи.");
        }
        else
        {
            // Если запрос не выполнен по другой причине, выводим сообщение об ошибке
            QMessageBox::critical(this, "Ошибка", query.lastError().text());
        }
        return;
    }

    // Выводим сообщение об удалении строки
    ui->teResult->append(QString("Удалено %1 строк").arg(query.numRowsAffected()));

    // Обновляем содержимое компонента таблицы
    selectAll();
}
void onb6::edit()
{
    // Получить выбранные значения из выпадающих списков
    QString pu2 = ui->le2->text(); // deal_date
    QString pu3 = ui->le3->text(); // deal_price
    QString cmb = ui->cmb1->currentData().toString(); // client_id
    QString cmbb = ui->cmb2->currentData().toString(); // employee_id
    QString cmbbb = ui->cmb3->currentData().toString(); // product_id
    QString cmbbbb = ui->cmb4->currentData().toString(); // warehouse_id
    QString cmbbbbb = ui->cmb5->currentData().toString(); // supplier_id

    // Проверка корректности формата даты
    QDate date = QDate::fromString(pu2, "yyyy-MM-dd");
    if (!date.isValid()) {
        QMessageBox::critical(this, "Ошибка", "Некорректный формат даты. Ожидается формат yyyy-MM-dd.");
        return;
    }

    // Проверка, что цена не отрицательная
    bool ok;
    double price = pu3.toDouble(&ok);
    if (!ok || price < 0) {
        QMessageBox::critical(this, "Ошибка", "Цена не может быть отрицательной.");
        return;
    }

    // Получаем текущую выбранную строку
    int curRow = ui->tw->currentRow();

    // Проверяем, что строка действительно выбрана
    if (curRow < 0) {
        ui->teResult->append("Внимание: строка не выбрана!");
        return;
    }

    // Получаем ID сделки, которую нужно обновить
    QString pupu = ui->tw->item(curRow, 0)->text();

    // Подготавливаем SQL запрос для обновления данных сделки
    QSqlQuery query;
    query.prepare("UPDATE deal SET deal_date = :1, deal_price = :2, client_id = :3, employee_id = :4, product_id = :5, warehouse_id = :6, supplier_id = :7 "
                  "WHERE deal_id = :8");
    query.bindValue(":1", pu2);
    query.bindValue(":2", pu3);
    query.bindValue(":3", cmb);
    query.bindValue(":4", cmbb);
    query.bindValue(":5", cmbbb);
    query.bindValue(":6", cmbbbb);
    query.bindValue(":7", cmbbbbb);
    query.bindValue(":8", pupu);

    // Выполняем запрос на обновление данных сделки
    if (!query.exec()) {
        ui->teResult->append("Ошибка: " + query.lastError().text());
        return;
    }

    ui->teResult->append("Успех: данные успешно обновлены.");
    selectAll(); // Обновить таблицу после обновления
}


void onb6::search()
{
    // Получаем текст из поля поиска
    QString currentSearchQuery = ui->leSearch->text().trimmed(); // Обрезаем начальные и конечные пробелы

    // Проверяем, пусто ли поле ввода
    if (currentSearchQuery.isEmpty())
    {
        // Если поле ввода пустое, вызываем функцию selectAll для выделения всех строк
        selectAll();
        return; // Завершаем выполнение функции
    }

    // Проверяем, изменилось ли значение поиска с предыдущего запроса
    if (currentSearchQuery != m_lastSearchQuery)
    {
        // Если значение изменилось, обновляем переменную с последним значением поиска
        m_lastSearchQuery = currentSearchQuery;

        // Сбрасываем индекс последнего найденного совпадения
        m_lastFoundIndex = -1;
    }

    // Очищаем выделение в таблице
    ui->tw->clearSelection();

    // Флаг для отслеживания найденных результатов
    bool foundMatch = false;

    // Проходим по всем строкам таблицы и ищем нужную строку
    for (int row = m_lastFoundIndex + 1; row < ui->tw->rowCount(); ++row)
    {
        // Получаем текст в каждой ячейке строки таблицы
        QString rowData;
        for (int col = 0; col < ui->tw->columnCount(); ++col)
        {
            QTableWidgetItem *item = ui->tw->item(row, col);
            if (item)
                rowData += item->text() + " ";
        }

        // Проверяем, содержит ли текст строки искомую подстроку
        if (rowData.contains(currentSearchQuery, Qt::CaseInsensitive))
        {
            // Выделяем найденную строку
            ui->tw->selectRow(row);

            // Прокручиваем таблицу к найденной строке
            ui->tw->scrollToItem(ui->tw->item(row, 0));

            // Устанавливаем флаг найденного элемента в true
            foundMatch = true;

            // Обновляем индекс последнего найденного совпадения
            m_lastFoundIndex = row;

            // Выходим из цикла, так как строка найдена
            break;
        }
    }

    // Если совпадение не было найдено, выводим сообщение об этом
    if (!foundMatch)
    {
        QMessageBox::information(this, "Поиск", "Больше совпадений не найдено.");
        // Сбрасываем индекс последнего найденного совпадения
        m_lastFoundIndex = -1;
    }
}
void onb6::generateReportRequest()
{
    // Вызываем функцию selectAll для получения данных о поставщиках из таблицы
    selectAll();

    // Создаем заголовок отчета
    QString reportText = "Отчет о Сделке:\n\n";
    reportText += "Уважаемые коллеги,\n\n";
    reportText += "Подготовлен отчет :\n";

    // Добавляем информацию о каждом поставщике из таблицы
    for (int row = 0; row < ui->tw->rowCount(); ++row) {
        QString pu1 = ui->tw->item(row, 0)->text();
        QString pu2 = ui->tw->item(row, 1)->text();
        QString pu3 = ui->tw->item(row, 2)->text();
        QString pu4 = ui->tw->item(row, 3)->text();
        QString pu5 = ui->tw->item(row, 4)->text();
        QString pu6 = ui->tw->item(row, 5)->text();
        QString pu7 = ui->tw->item(row, 6)->text();
        QString pu8 = ui->tw->item(row, 7)->text();



        reportText += "- ID " + pu1 + ", Дата " + pu2 + ", Цена " + pu3 + ", Клиент " + pu4 + ", Работник " + pu5 + ", Продукт " + pu6 +  ", Склад " + pu7 +  ", Поставщик " + pu8 + ";\n";
    }

    reportText += "\nС уважением,\n";
    reportText += "Администрация HlebZavod"; // Замените "Ваше имя" на ваше имя или название компании

    // Имя файла для сохранения отчета
    QString fileName = "/Users/egoralanov/Desktop/отчеты/сделки.txt";

    QFile file(fileName);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        out << reportText;
        file.close();
        QMessageBox::information(this, "Успех", "Отчет успешно сохранен в папке отчеты, под именем сделки");
    } else {
        QMessageBox::critical(this, "Ошибка", "Не удалось создать файл для сохранения отчета.");
    }
}


void onb6::on_tw_itemSelectionChanged()
{
    int curRow = ui->tw->currentRow();

    if (curRow < 0)
    {
        ui->cmb1->setCurrentIndex(0);
        ui->cmb2->setCurrentIndex(0);
        ui->cmb3->setCurrentIndex(0);
        ui->cmb4->setCurrentIndex(0);
        ui->cmb5->setCurrentIndex(0);


        ui->le1->clear();
        ui->le2->clear();
        ui->le3->clear();

        return;
    }

    QString pu1 = ui->tw->item(curRow, 0)->text();
    QString pu2 = ui->tw->item(curRow, 1)->text();
    QString pu3 = ui->tw->item(curRow, 2)->text();
    QString cmb = ui->tw->item(curRow, 3)->text();
    QString cmbb = ui->tw->item(curRow, 4)->text();
    QString cmbbb = ui->tw->item(curRow, 5)->text();
    QString cmbbbb = ui->tw->item(curRow, 6)->text();
    QString cmbbbbb = ui->tw->item(curRow, 7)->text();





    ui->le1->setText(pu1);
    ui->le2->setText(pu2);
    ui->le3->setText(pu3);
    ui->cmb1->setCurrentText(cmb);
    ui->cmb2->setCurrentText(cmbb);
    ui->cmb3->setCurrentText(cmbbb);
    ui->cmb4->setCurrentText(cmbbbb);
    ui->cmb5->setCurrentText(cmbbbbb);



}


void onb6::clean()
{
    ui->cmb1->setCurrentIndex(0);
    ui->cmb2->setCurrentIndex(0);
    ui->cmb3->setCurrentIndex(0);
    ui->cmb4->setCurrentIndex(0);
    ui->cmb5->setCurrentIndex(0);


    ui->le1->clear();
    ui->le2->clear();
    ui->le3->clear();

}

