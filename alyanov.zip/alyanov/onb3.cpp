#include "onb3.h"
#include "ui_onb3.h"

onb3::onb3(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::onb3)
{
    ui->setupUi(this);
}

onb3::~onb3()
{
    delete ui;
}
