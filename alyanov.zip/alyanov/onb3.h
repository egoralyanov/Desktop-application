#ifndef ONB3_H
#define ONB3_H

#include <QDialog>

namespace Ui {
class onb3;
}

class onb3 : public QDialog
{
    Q_OBJECT

public:
    explicit onb3(QWidget *parent = nullptr);
    ~onb3();

private:
    Ui::onb3 *ui;
};

#endif // ONB3_H
