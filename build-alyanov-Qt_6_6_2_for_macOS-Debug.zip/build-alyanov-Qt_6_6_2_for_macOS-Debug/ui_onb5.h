/********************************************************************************
** Form generated from reading UI file 'onb5.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ONB5_H
#define UI_ONB5_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_onb5
{
public:
    QTableWidget *tw;
    QPushButton *btnSearch;
    QPushButton *btnExit;
    QLineEdit *leSearch;
    QFrame *frame;
    QLineEdit *le2;
    QPushButton *btn3;
    QPushButton *btn2;
    QPushButton *btn1;
    QPushButton *btn4;
    QLabel *lbId_2;
    QLineEdit *le1;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *le3;
    QPushButton *btnReport;
    QTextEdit *teResult;

    void setupUi(QDialog *onb5)
    {
        if (onb5->objectName().isEmpty())
            onb5->setObjectName("onb5");
        onb5->resize(682, 435);
        tw = new QTableWidget(onb5);
        tw->setObjectName("tw");
        tw->setGeometry(QRect(347, 50, 301, 221));
        btnSearch = new QPushButton(onb5);
        btnSearch->setObjectName("btnSearch");
        btnSearch->setGeometry(QRect(540, 20, 100, 32));
        btnExit = new QPushButton(onb5);
        btnExit->setObjectName("btnExit");
        btnExit->setGeometry(QRect(550, 360, 100, 32));
        leSearch = new QLineEdit(onb5);
        leSearch->setObjectName("leSearch");
        leSearch->setGeometry(QRect(410, 30, 113, 21));
        frame = new QFrame(onb5);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(20, 40, 311, 231));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Plain);
        le2 = new QLineEdit(frame);
        le2->setObjectName("le2");
        le2->setGeometry(QRect(170, 90, 121, 21));
        btn3 = new QPushButton(frame);
        btn3->setObjectName("btn3");
        btn3->setGeometry(QRect(220, 200, 81, 32));
        btn2 = new QPushButton(frame);
        btn2->setObjectName("btn2");
        btn2->setGeometry(QRect(110, 200, 91, 32));
        btn1 = new QPushButton(frame);
        btn1->setObjectName("btn1");
        btn1->setGeometry(QRect(20, 200, 81, 32));
        btn4 = new QPushButton(frame);
        btn4->setObjectName("btn4");
        btn4->setGeometry(QRect(190, 10, 100, 32));
        lbId_2 = new QLabel(frame);
        lbId_2->setObjectName("lbId_2");
        lbId_2->setGeometry(QRect(200, 50, 11, 16));
        le1 = new QLineEdit(frame);
        le1->setObjectName("le1");
        le1->setGeometry(QRect(240, 50, 51, 21));
        label = new QLabel(frame);
        label->setObjectName("label");
        label->setGeometry(QRect(80, 90, 71, 20));
        label_2 = new QLabel(frame);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(60, 120, 91, 20));
        le3 = new QLineEdit(frame);
        le3->setObjectName("le3");
        le3->setGeometry(QRect(170, 120, 121, 21));
        btnReport = new QPushButton(onb5);
        btnReport->setObjectName("btnReport");
        btnReport->setGeometry(QRect(20, 360, 100, 32));
        teResult = new QTextEdit(onb5);
        teResult->setObjectName("teResult");
        teResult->setGeometry(QRect(20, 280, 631, 74));
        teResult->setReadOnly(true);

        retranslateUi(onb5);

        QMetaObject::connectSlotsByName(onb5);
    } // setupUi

    void retranslateUi(QDialog *onb5)
    {
        onb5->setWindowTitle(QCoreApplication::translate("onb5", "Dialog", nullptr));
        btnSearch->setText(QCoreApplication::translate("onb5", "\320\237\320\276\320\270\321\201\320\272", nullptr));
        btnExit->setText(QCoreApplication::translate("onb5", "\320\222\321\213\321\205\320\276\320\264", nullptr));
        btn3->setText(QCoreApplication::translate("onb5", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214", nullptr));
        btn2->setText(QCoreApplication::translate("onb5", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214", nullptr));
        btn1->setText(QCoreApplication::translate("onb5", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214", nullptr));
        btn4->setText(QCoreApplication::translate("onb5", "\320\236\321\207\320\270\321\201\321\202\320\270\321\202\321\214", nullptr));
        lbId_2->setText(QCoreApplication::translate("onb5", "id", nullptr));
        label->setText(QCoreApplication::translate("onb5", "\320\230\320\274\321\217", nullptr));
        label_2->setText(QCoreApplication::translate("onb5", "\320\224\320\276\320\273\320\266\320\275\320\276\321\201\321\202\321\214", nullptr));
        btnReport->setText(QCoreApplication::translate("onb5", "\320\236\321\202\321\207\320\265\321\202", nullptr));
    } // retranslateUi

};

namespace Ui {
    class onb5: public Ui_onb5 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ONB5_H
