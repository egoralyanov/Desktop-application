/********************************************************************************
** Form generated from reading UI file 'onb4.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ONB4_H
#define UI_ONB4_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_onb4
{
public:
    QPushButton *btnExit;
    QPushButton *btnReport;
    QLineEdit *leSearch;
    QTextEdit *teResult;
    QPushButton *btnSearch;
    QTableWidget *tw;
    QFrame *frame;
    QLineEdit *le1;
    QLineEdit *le2;
    QLineEdit *le3;
    QPushButton *btn3;
    QPushButton *btn2;
    QPushButton *btn1;
    QPushButton *btn4;
    QComboBox *cmb1;
    QLabel *lbStartdata;
    QLabel *lbFinishdata;
    QLabel *lbPrice;
    QLabel *lbStaff;
    QLineEdit *le4;
    QComboBox *cmb2;
    QLabel *lbStaff_2;
    QLabel *lbStaff_3;

    void setupUi(QDialog *onb4)
    {
        if (onb4->objectName().isEmpty())
            onb4->setObjectName("onb4");
        onb4->resize(678, 432);
        btnExit = new QPushButton(onb4);
        btnExit->setObjectName("btnExit");
        btnExit->setGeometry(QRect(540, 360, 100, 32));
        btnReport = new QPushButton(onb4);
        btnReport->setObjectName("btnReport");
        btnReport->setGeometry(QRect(20, 360, 100, 32));
        leSearch = new QLineEdit(onb4);
        leSearch->setObjectName("leSearch");
        leSearch->setGeometry(QRect(380, 20, 113, 21));
        teResult = new QTextEdit(onb4);
        teResult->setObjectName("teResult");
        teResult->setGeometry(QRect(10, 280, 631, 74));
        teResult->setReadOnly(true);
        btnSearch = new QPushButton(onb4);
        btnSearch->setObjectName("btnSearch");
        btnSearch->setGeometry(QRect(510, 10, 100, 32));
        tw = new QTableWidget(onb4);
        tw->setObjectName("tw");
        tw->setGeometry(QRect(337, 50, 301, 221));
        frame = new QFrame(onb4);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(10, 40, 311, 231));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Plain);
        le1 = new QLineEdit(frame);
        le1->setObjectName("le1");
        le1->setGeometry(QRect(50, 40, 51, 21));
        le2 = new QLineEdit(frame);
        le2->setObjectName("le2");
        le2->setGeometry(QRect(90, 60, 201, 21));
        le3 = new QLineEdit(frame);
        le3->setObjectName("le3");
        le3->setGeometry(QRect(90, 80, 201, 21));
        btn3 = new QPushButton(frame);
        btn3->setObjectName("btn3");
        btn3->setGeometry(QRect(220, 200, 81, 32));
        btn2 = new QPushButton(frame);
        btn2->setObjectName("btn2");
        btn2->setGeometry(QRect(110, 200, 91, 32));
        btn1 = new QPushButton(frame);
        btn1->setObjectName("btn1");
        btn1->setGeometry(QRect(20, 200, 81, 32));
        btn4 = new QPushButton(frame);
        btn4->setObjectName("btn4");
        btn4->setGeometry(QRect(190, 10, 100, 32));
        cmb1 = new QComboBox(frame);
        cmb1->setObjectName("cmb1");
        cmb1->setGeometry(QRect(90, 120, 211, 32));
        lbStartdata = new QLabel(frame);
        lbStartdata->setObjectName("lbStartdata");
        lbStartdata->setGeometry(QRect(10, 40, 21, 16));
        lbFinishdata = new QLabel(frame);
        lbFinishdata->setObjectName("lbFinishdata");
        lbFinishdata->setGeometry(QRect(10, 60, 61, 16));
        lbPrice = new QLabel(frame);
        lbPrice->setObjectName("lbPrice");
        lbPrice->setGeometry(QRect(10, 80, 71, 16));
        lbStaff = new QLabel(frame);
        lbStaff->setObjectName("lbStaff");
        lbStaff->setGeometry(QRect(10, 100, 71, 16));
        le4 = new QLineEdit(frame);
        le4->setObjectName("le4");
        le4->setGeometry(QRect(90, 100, 201, 21));
        cmb2 = new QComboBox(frame);
        cmb2->setObjectName("cmb2");
        cmb2->setGeometry(QRect(90, 140, 211, 32));
        lbStaff_2 = new QLabel(frame);
        lbStaff_2->setObjectName("lbStaff_2");
        lbStaff_2->setGeometry(QRect(10, 120, 71, 16));
        lbStaff_3 = new QLabel(frame);
        lbStaff_3->setObjectName("lbStaff_3");
        lbStaff_3->setGeometry(QRect(10, 140, 61, 21));

        retranslateUi(onb4);

        QMetaObject::connectSlotsByName(onb4);
    } // setupUi

    void retranslateUi(QDialog *onb4)
    {
        onb4->setWindowTitle(QCoreApplication::translate("onb4", "Dialog", nullptr));
        btnExit->setText(QCoreApplication::translate("onb4", "\320\222\321\213\321\205\320\276\320\264", nullptr));
        btnReport->setText(QCoreApplication::translate("onb4", "\320\236\321\202\321\207\320\265\321\202", nullptr));
        btnSearch->setText(QCoreApplication::translate("onb4", "\320\237\320\276\320\270\321\201\320\272", nullptr));
        btn3->setText(QCoreApplication::translate("onb4", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214", nullptr));
        btn2->setText(QCoreApplication::translate("onb4", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214", nullptr));
        btn1->setText(QCoreApplication::translate("onb4", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214", nullptr));
        btn4->setText(QCoreApplication::translate("onb4", "\320\236\321\207\320\270\321\201\321\202\320\270\321\202\321\214", nullptr));
        lbStartdata->setText(QCoreApplication::translate("onb4", "id", nullptr));
        lbFinishdata->setText(QCoreApplication::translate("onb4", "\320\235\320\260\320\267\320\262\320\260\320\275\320\270\320\265", nullptr));
        lbPrice->setText(QCoreApplication::translate("onb4", "\320\232\320\260\320\273\320\276\321\200\320\270\320\270", nullptr));
        lbStaff->setText(QCoreApplication::translate("onb4", "\320\222\320\265\321\201", nullptr));
        lbStaff_2->setText(QCoreApplication::translate("onb4", "\320\237\320\276\321\201\321\202\320\260\320\262\321\211\320\270\320\272", nullptr));
        lbStaff_3->setText(QCoreApplication::translate("onb4", "\320\241\320\272\320\273\320\260\320\264", nullptr));
    } // retranslateUi

};

namespace Ui {
    class onb4: public Ui_onb4 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ONB4_H
