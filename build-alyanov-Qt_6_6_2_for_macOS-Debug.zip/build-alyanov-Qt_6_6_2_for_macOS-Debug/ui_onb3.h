/********************************************************************************
** Form generated from reading UI file 'onb3.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ONB3_H
#define UI_ONB3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_onb3
{
public:

    void setupUi(QDialog *onb3)
    {
        if (onb3->objectName().isEmpty())
            onb3->setObjectName("onb3");
        onb3->resize(400, 300);

        retranslateUi(onb3);

        QMetaObject::connectSlotsByName(onb3);
    } // setupUi

    void retranslateUi(QDialog *onb3)
    {
        onb3->setWindowTitle(QCoreApplication::translate("onb3", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class onb3: public Ui_onb3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ONB3_H
