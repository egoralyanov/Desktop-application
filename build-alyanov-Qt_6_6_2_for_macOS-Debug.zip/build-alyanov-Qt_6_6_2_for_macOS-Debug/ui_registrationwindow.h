/********************************************************************************
** Form generated from reading UI file 'registrationwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTRATIONWINDOW_H
#define UI_REGISTRATIONWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_registrationwindow
{
public:
    QLineEdit *leLogin;
    QLineEdit *lePassword;
    QLabel *lbRegistration;
    QPushButton *btnWelcome;
    QLabel *lbLogin;
    QLabel *lbPassword;

    void setupUi(QDialog *registrationwindow)
    {
        if (registrationwindow->objectName().isEmpty())
            registrationwindow->setObjectName("registrationwindow");
        registrationwindow->resize(325, 286);
        leLogin = new QLineEdit(registrationwindow);
        leLogin->setObjectName("leLogin");
        leLogin->setGeometry(QRect(100, 70, 125, 21));
        lePassword = new QLineEdit(registrationwindow);
        lePassword->setObjectName("lePassword");
        lePassword->setGeometry(QRect(100, 120, 125, 21));
        lbRegistration = new QLabel(registrationwindow);
        lbRegistration->setObjectName("lbRegistration");
        lbRegistration->setGeometry(QRect(120, 20, 80, 16));
        btnWelcome = new QPushButton(registrationwindow);
        btnWelcome->setObjectName("btnWelcome");
        btnWelcome->setGeometry(QRect(110, 180, 100, 32));
        lbLogin = new QLabel(registrationwindow);
        lbLogin->setObjectName("lbLogin");
        lbLogin->setGeometry(QRect(30, 70, 58, 16));
        lbPassword = new QLabel(registrationwindow);
        lbPassword->setObjectName("lbPassword");
        lbPassword->setGeometry(QRect(30, 120, 46, 16));

        retranslateUi(registrationwindow);

        QMetaObject::connectSlotsByName(registrationwindow);
    } // setupUi

    void retranslateUi(QDialog *registrationwindow)
    {
        registrationwindow->setWindowTitle(QCoreApplication::translate("registrationwindow", "registrationwindow", nullptr));
        lbRegistration->setText(QCoreApplication::translate("registrationwindow", "\320\240\320\265\320\263\320\270\321\201\321\202\321\200\320\260\321\206\320\270\321\217", nullptr));
        btnWelcome->setText(QCoreApplication::translate("registrationwindow", "\320\222\320\276\320\271\321\202\320\270", nullptr));
        lbLogin->setText(QCoreApplication::translate("registrationwindow", "\320\233\320\276\320\263\320\270\320\275", nullptr));
        lbPassword->setText(QCoreApplication::translate("registrationwindow", "\320\237\320\260\321\200\320\276\320\273\321\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class registrationwindow: public Ui_registrationwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTRATIONWINDOW_H
