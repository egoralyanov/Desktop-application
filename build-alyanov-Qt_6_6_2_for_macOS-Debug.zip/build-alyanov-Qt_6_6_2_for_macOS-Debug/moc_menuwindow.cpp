/****************************************************************************
** Meta object code from reading C++ file 'menuwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../alyanov/menuwindow.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'menuwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSmenuwindowENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSmenuwindowENDCLASS = QtMocHelpers::stringData(
    "menuwindow",
    "onb11",
    "",
    "onb22",
    "onb33",
    "onb44",
    "onb55",
    "onb66",
    "onb77",
    "onExitButtonClicked",
    "onReturnToRegistrationClicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSmenuwindowENDCLASS_t {
    uint offsetsAndSizes[22];
    char stringdata0[11];
    char stringdata1[6];
    char stringdata2[1];
    char stringdata3[6];
    char stringdata4[6];
    char stringdata5[6];
    char stringdata6[6];
    char stringdata7[6];
    char stringdata8[6];
    char stringdata9[20];
    char stringdata10[30];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSmenuwindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSmenuwindowENDCLASS_t qt_meta_stringdata_CLASSmenuwindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "menuwindow"
        QT_MOC_LITERAL(11, 5),  // "onb11"
        QT_MOC_LITERAL(17, 0),  // ""
        QT_MOC_LITERAL(18, 5),  // "onb22"
        QT_MOC_LITERAL(24, 5),  // "onb33"
        QT_MOC_LITERAL(30, 5),  // "onb44"
        QT_MOC_LITERAL(36, 5),  // "onb55"
        QT_MOC_LITERAL(42, 5),  // "onb66"
        QT_MOC_LITERAL(48, 5),  // "onb77"
        QT_MOC_LITERAL(54, 19),  // "onExitButtonClicked"
        QT_MOC_LITERAL(74, 29)   // "onReturnToRegistrationClicked"
    },
    "menuwindow",
    "onb11",
    "",
    "onb22",
    "onb33",
    "onb44",
    "onb55",
    "onb66",
    "onb77",
    "onExitButtonClicked",
    "onReturnToRegistrationClicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSmenuwindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   68,    2, 0x08,    1 /* Private */,
       3,    0,   69,    2, 0x08,    2 /* Private */,
       4,    0,   70,    2, 0x08,    3 /* Private */,
       5,    0,   71,    2, 0x08,    4 /* Private */,
       6,    0,   72,    2, 0x08,    5 /* Private */,
       7,    0,   73,    2, 0x08,    6 /* Private */,
       8,    0,   74,    2, 0x08,    7 /* Private */,
       9,    0,   75,    2, 0x08,    8 /* Private */,
      10,    0,   76,    2, 0x08,    9 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject menuwindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSmenuwindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSmenuwindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSmenuwindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<menuwindow, std::true_type>,
        // method 'onb11'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onb22'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onb33'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onb44'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onb55'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onb66'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onb77'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onExitButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onReturnToRegistrationClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void menuwindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<menuwindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onb11(); break;
        case 1: _t->onb22(); break;
        case 2: _t->onb33(); break;
        case 3: _t->onb44(); break;
        case 4: _t->onb55(); break;
        case 5: _t->onb66(); break;
        case 6: _t->onb77(); break;
        case 7: _t->onExitButtonClicked(); break;
        case 8: _t->onReturnToRegistrationClicked(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *menuwindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *menuwindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSmenuwindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int menuwindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }
    return _id;
}
QT_WARNING_POP
