/********************************************************************************
** Form generated from reading UI file 'onb2.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ONB2_H
#define UI_ONB2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_onb2
{
public:
    QTableWidget *tw;
    QPushButton *btnSearch;
    QPushButton *btnExit;
    QLineEdit *leSearch;
    QFrame *frame;
    QLineEdit *le2;
    QPushButton *btn3;
    QPushButton *btn2;
    QPushButton *btn1;
    QPushButton *btn4;
    QLabel *lbId_2;
    QLineEdit *le1;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *le3;
    QLineEdit *le4;
    QLabel *label_3;
    QPushButton *btnReport;
    QTextEdit *teResult;

    void setupUi(QDialog *onb2)
    {
        if (onb2->objectName().isEmpty())
            onb2->setObjectName("onb2");
        onb2->resize(691, 409);
        tw = new QTableWidget(onb2);
        tw->setObjectName("tw");
        tw->setGeometry(QRect(347, 40, 301, 221));
        btnSearch = new QPushButton(onb2);
        btnSearch->setObjectName("btnSearch");
        btnSearch->setGeometry(QRect(540, 10, 100, 32));
        btnExit = new QPushButton(onb2);
        btnExit->setObjectName("btnExit");
        btnExit->setGeometry(QRect(550, 350, 100, 32));
        leSearch = new QLineEdit(onb2);
        leSearch->setObjectName("leSearch");
        leSearch->setGeometry(QRect(410, 20, 113, 21));
        frame = new QFrame(onb2);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(20, 30, 311, 231));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Plain);
        le2 = new QLineEdit(frame);
        le2->setObjectName("le2");
        le2->setGeometry(QRect(170, 90, 121, 21));
        btn3 = new QPushButton(frame);
        btn3->setObjectName("btn3");
        btn3->setGeometry(QRect(220, 200, 81, 32));
        btn2 = new QPushButton(frame);
        btn2->setObjectName("btn2");
        btn2->setGeometry(QRect(110, 200, 91, 32));
        btn1 = new QPushButton(frame);
        btn1->setObjectName("btn1");
        btn1->setGeometry(QRect(20, 200, 81, 32));
        btn4 = new QPushButton(frame);
        btn4->setObjectName("btn4");
        btn4->setGeometry(QRect(190, 10, 100, 32));
        lbId_2 = new QLabel(frame);
        lbId_2->setObjectName("lbId_2");
        lbId_2->setGeometry(QRect(200, 50, 11, 16));
        le1 = new QLineEdit(frame);
        le1->setObjectName("le1");
        le1->setGeometry(QRect(240, 50, 51, 21));
        label = new QLabel(frame);
        label->setObjectName("label");
        label->setGeometry(QRect(80, 90, 71, 20));
        label_2 = new QLabel(frame);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(100, 120, 51, 20));
        le3 = new QLineEdit(frame);
        le3->setObjectName("le3");
        le3->setGeometry(QRect(170, 120, 121, 21));
        le4 = new QLineEdit(frame);
        le4->setObjectName("le4");
        le4->setGeometry(QRect(170, 150, 121, 21));
        label_3 = new QLabel(frame);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(70, 150, 81, 20));
        btnReport = new QPushButton(onb2);
        btnReport->setObjectName("btnReport");
        btnReport->setGeometry(QRect(20, 350, 100, 32));
        teResult = new QTextEdit(onb2);
        teResult->setObjectName("teResult");
        teResult->setGeometry(QRect(20, 270, 631, 74));
        teResult->setReadOnly(true);

        retranslateUi(onb2);

        QMetaObject::connectSlotsByName(onb2);
    } // setupUi

    void retranslateUi(QDialog *onb2)
    {
        onb2->setWindowTitle(QCoreApplication::translate("onb2", "Dialog", nullptr));
        btnSearch->setText(QCoreApplication::translate("onb2", "\320\237\320\276\320\270\321\201\320\272", nullptr));
        btnExit->setText(QCoreApplication::translate("onb2", "\320\222\321\213\321\205\320\276\320\264", nullptr));
        btn3->setText(QCoreApplication::translate("onb2", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214", nullptr));
        btn2->setText(QCoreApplication::translate("onb2", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214", nullptr));
        btn1->setText(QCoreApplication::translate("onb2", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214", nullptr));
        btn4->setText(QCoreApplication::translate("onb2", "\320\236\321\207\320\270\321\201\321\202\320\270\321\202\321\214", nullptr));
        lbId_2->setText(QCoreApplication::translate("onb2", "id", nullptr));
        label->setText(QCoreApplication::translate("onb2", "\320\235\320\260\320\267\320\262\320\260\320\275\320\270\320\265", nullptr));
        label_2->setText(QCoreApplication::translate("onb2", "\320\220\320\264\321\200\320\265\321\201", nullptr));
        label_3->setText(QCoreApplication::translate("onb2", "\320\225\320\274\320\272\320\276\321\201\321\202\321\214", nullptr));
        btnReport->setText(QCoreApplication::translate("onb2", "\320\236\321\202\321\207\320\265\321\202", nullptr));
    } // retranslateUi

};

namespace Ui {
    class onb2: public Ui_onb2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ONB2_H
