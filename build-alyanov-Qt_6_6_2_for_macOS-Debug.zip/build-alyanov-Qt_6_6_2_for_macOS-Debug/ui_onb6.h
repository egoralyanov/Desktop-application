/********************************************************************************
** Form generated from reading UI file 'onb6.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ONB6_H
#define UI_ONB6_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_onb6
{
public:
    QLineEdit *leSearch;
    QPushButton *btnExit;
    QPushButton *btnReport;
    QPushButton *btnSearch;
    QTextEdit *teResult;
    QTableWidget *tw;
    QFrame *frame;
    QLineEdit *le1;
    QLineEdit *le2;
    QLineEdit *le3;
    QPushButton *btn3;
    QPushButton *btn2;
    QPushButton *btn1;
    QPushButton *btn4;
    QComboBox *cmb1;
    QLabel *lbStartdata;
    QLabel *lbFinishdata;
    QLabel *lbPrice;
    QLabel *lbStaff;
    QComboBox *cmb2;
    QLabel *lbStaff_2;
    QLabel *lbStaff_3;
    QComboBox *cmb3;
    QComboBox *cmb4;
    QLabel *lbStaff_4;
    QComboBox *cmb5;
    QLabel *lbStaff_5;

    void setupUi(QDialog *onb6)
    {
        if (onb6->objectName().isEmpty())
            onb6->setObjectName("onb6");
        onb6->resize(671, 422);
        leSearch = new QLineEdit(onb6);
        leSearch->setObjectName("leSearch");
        leSearch->setGeometry(QRect(380, 20, 113, 21));
        btnExit = new QPushButton(onb6);
        btnExit->setObjectName("btnExit");
        btnExit->setGeometry(QRect(540, 360, 100, 32));
        btnReport = new QPushButton(onb6);
        btnReport->setObjectName("btnReport");
        btnReport->setGeometry(QRect(20, 360, 100, 32));
        btnSearch = new QPushButton(onb6);
        btnSearch->setObjectName("btnSearch");
        btnSearch->setGeometry(QRect(510, 10, 100, 32));
        teResult = new QTextEdit(onb6);
        teResult->setObjectName("teResult");
        teResult->setGeometry(QRect(10, 280, 631, 74));
        teResult->setReadOnly(true);
        tw = new QTableWidget(onb6);
        tw->setObjectName("tw");
        tw->setGeometry(QRect(337, 50, 301, 221));
        frame = new QFrame(onb6);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(10, 40, 311, 231));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Plain);
        le1 = new QLineEdit(frame);
        le1->setObjectName("le1");
        le1->setGeometry(QRect(40, 20, 51, 21));
        le2 = new QLineEdit(frame);
        le2->setObjectName("le2");
        le2->setGeometry(QRect(90, 40, 201, 21));
        le3 = new QLineEdit(frame);
        le3->setObjectName("le3");
        le3->setGeometry(QRect(90, 60, 201, 21));
        btn3 = new QPushButton(frame);
        btn3->setObjectName("btn3");
        btn3->setGeometry(QRect(220, 200, 81, 32));
        btn2 = new QPushButton(frame);
        btn2->setObjectName("btn2");
        btn2->setGeometry(QRect(110, 200, 91, 32));
        btn1 = new QPushButton(frame);
        btn1->setObjectName("btn1");
        btn1->setGeometry(QRect(20, 200, 81, 32));
        btn4 = new QPushButton(frame);
        btn4->setObjectName("btn4");
        btn4->setGeometry(QRect(190, 10, 100, 32));
        cmb1 = new QComboBox(frame);
        cmb1->setObjectName("cmb1");
        cmb1->setGeometry(QRect(90, 80, 211, 32));
        lbStartdata = new QLabel(frame);
        lbStartdata->setObjectName("lbStartdata");
        lbStartdata->setGeometry(QRect(10, 20, 21, 16));
        lbFinishdata = new QLabel(frame);
        lbFinishdata->setObjectName("lbFinishdata");
        lbFinishdata->setGeometry(QRect(20, 40, 61, 16));
        lbPrice = new QLabel(frame);
        lbPrice->setObjectName("lbPrice");
        lbPrice->setGeometry(QRect(20, 60, 71, 16));
        lbStaff = new QLabel(frame);
        lbStaff->setObjectName("lbStaff");
        lbStaff->setGeometry(QRect(10, 90, 71, 16));
        cmb2 = new QComboBox(frame);
        cmb2->setObjectName("cmb2");
        cmb2->setGeometry(QRect(90, 100, 211, 32));
        lbStaff_2 = new QLabel(frame);
        lbStaff_2->setObjectName("lbStaff_2");
        lbStaff_2->setGeometry(QRect(10, 100, 71, 31));
        lbStaff_3 = new QLabel(frame);
        lbStaff_3->setObjectName("lbStaff_3");
        lbStaff_3->setGeometry(QRect(10, 150, 61, 16));
        cmb3 = new QComboBox(frame);
        cmb3->setObjectName("cmb3");
        cmb3->setGeometry(QRect(90, 120, 211, 32));
        cmb4 = new QComboBox(frame);
        cmb4->setObjectName("cmb4");
        cmb4->setGeometry(QRect(90, 140, 211, 32));
        lbStaff_4 = new QLabel(frame);
        lbStaff_4->setObjectName("lbStaff_4");
        lbStaff_4->setGeometry(QRect(10, 170, 71, 21));
        cmb5 = new QComboBox(frame);
        cmb5->setObjectName("cmb5");
        cmb5->setGeometry(QRect(90, 160, 211, 32));
        lbStaff_5 = new QLabel(frame);
        lbStaff_5->setObjectName("lbStaff_5");
        lbStaff_5->setGeometry(QRect(10, 119, 71, 31));

        retranslateUi(onb6);

        QMetaObject::connectSlotsByName(onb6);
    } // setupUi

    void retranslateUi(QDialog *onb6)
    {
        onb6->setWindowTitle(QCoreApplication::translate("onb6", "Dialog", nullptr));
        btnExit->setText(QCoreApplication::translate("onb6", "\320\222\321\213\321\205\320\276\320\264", nullptr));
        btnReport->setText(QCoreApplication::translate("onb6", "\320\236\321\202\321\207\320\265\321\202", nullptr));
        btnSearch->setText(QCoreApplication::translate("onb6", "\320\237\320\276\320\270\321\201\320\272", nullptr));
        btn3->setText(QCoreApplication::translate("onb6", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214", nullptr));
        btn2->setText(QCoreApplication::translate("onb6", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214", nullptr));
        btn1->setText(QCoreApplication::translate("onb6", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214", nullptr));
        btn4->setText(QCoreApplication::translate("onb6", "\320\236\321\207\320\270\321\201\321\202\320\270\321\202\321\214", nullptr));
        lbStartdata->setText(QCoreApplication::translate("onb6", "id", nullptr));
        lbFinishdata->setText(QCoreApplication::translate("onb6", "\320\224\320\260\321\202\320\260 ", nullptr));
        lbPrice->setText(QCoreApplication::translate("onb6", "\320\246\320\265\320\275\320\260", nullptr));
        lbStaff->setText(QCoreApplication::translate("onb6", "\320\232\320\273\320\270\320\265\320\275\321\202", nullptr));
        lbStaff_2->setText(QCoreApplication::translate("onb6", "\320\240\320\260\320\261\320\276\321\202\320\275\320\270\320\272", nullptr));
        lbStaff_3->setText(QCoreApplication::translate("onb6", "\320\241\320\272\320\273\320\260\320\264", nullptr));
        lbStaff_4->setText(QCoreApplication::translate("onb6", "\320\237\320\276\321\201\321\202\320\260\320\262\321\211\320\270\320\272", nullptr));
        lbStaff_5->setText(QCoreApplication::translate("onb6", "\320\237\321\200\320\276\320\264\321\203\320\272\321\202", nullptr));
    } // retranslateUi

};

namespace Ui {
    class onb6: public Ui_onb6 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ONB6_H
